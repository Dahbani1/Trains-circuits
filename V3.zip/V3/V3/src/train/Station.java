package train;

/**
 * The Station class represents a station. It is a subclass of the {@link Element} class.
 * A Station is characterized by a name and a number of platforms (thus the number of trains it can accommodate at a given time).
 * 
 * @author Fabien Dagnat <fabien.dagnat@imt-atlantique.fr>
 * @author Philippe Tanguy <philippe.tanguy@imt-atlantique.fr>
 */
public class Station extends Element {

	/**
	 * Constructor of the Station class. Initializes the Station with a name, size, and number of trains.
	 * @param name The name of the Station.
	 * @param size The size of the Station, representing the number of platforms.
	 * @param trains The number of trains in the Station.
	 * @throws NullPointerException if the name is null or the size is less than or equal to 0.
	 */
	public Station(String name, int size, int trains) {
		super(name, size, trains);
		if(name == null || size <=0)
			throw new NullPointerException();
	}

	/**
	 * Notifies the trains in the Station and updates their Position.
	 * If the railway direction is not null and not the same as the train direction, it waits.
	 * After a Train is notified, the number of trains in the Station is decremented, the Position of the Train is updated,
	 * the railway direction is set to the train direction, the number of trains on the railway is incremented, and all waiting threads are notified.
	 * @param t The Train to be notified.
	 */
	@Override
	public synchronized void notifyTrains(Train t) {
		Direction trainDirection = t.getPosition().getDirection();
		while(this.railway.railwayDirection != null & this.railway.railwayDirection != trainDirection) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		this.decrementTrains();
		t.getPosition().setElement(t.nextElement());
		this.railway.railwayDirection = trainDirection;
		this.railway.railwayTrains++;
		notifyAll();
	}

	/**
	 * Allows a Train to enter the Station if it is not full.
	 * After a Train is allowed to enter, the number of trains in the Station is incremented, the number of trains on the railway is decremented,
	 * if there are no trains on the railway, the railway direction is set to null, and all waiting threads are notified.
	 * @param t The Train to be allowed.
	 */
	@Override
	public synchronized void allowTrain(Train t) {
		while (this.isFull()) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		this.incrementTrains();
		this.railway.railwayTrains--;
		this.railway.railwayDirection = this.railway.railwayTrains==0 ? null : this.railway.railwayDirection;
		notifyAll();
	}
}
